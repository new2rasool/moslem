"""MusicRasool callbacks package."""
